package com.example.Gym.ShowControllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.Gym.Dto.MemberDto;
import com.example.Gym.Services.MemberService;

@Controller
@RequestMapping("/admin/members")
public class MembersAdminController {

    @Autowired
    private MemberService memberService;

    @GetMapping
    public String listMembers(Model model) {
        List<MemberDto> members = memberService.findAllMembers();
        
        if (members == null || members.isEmpty()) {
            System.out.println("No members found or list is null.");
        } else {
            members.forEach(member -> {
                if (member != null) {
                    System.out.println("Member ID: " + member.getMemberId());
                } else {
                    System.out.println("Found a null member in the list.");
                }
            });
        }
        
        model.addAttribute("members", members);
        return "MembersTemp";
    }

     @PostMapping("/add")
    public String addMember(@ModelAttribute MemberDto memberDto) {
        memberService.saveMember(memberDto); // Adjust based on your service implementation
        return "redirect:/admin/members"; // Redirect to the members list page after adding
    }
    
    
}
