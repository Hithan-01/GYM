package com.example.Gym.ShowControllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class HomeController {

    @GetMapping
    public String showHomePage(Model model) {
        // Add any necessary data to the model if required
        return "HomeTemp";  // This should point to your home page template, e.g., Home.html
    }
}
